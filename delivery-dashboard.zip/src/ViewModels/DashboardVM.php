<?php
require_once __DIR__ . '/../Models/DataRepository.php';

class DashboardVM {
    private $repository;

    public function __construct() {
        $this->repository = new DataRepository();
    }

    /**
     * Mengambil data dari Model dan memformatnya untuk kebutuhan View (JSON)
     */
    public function getDashboardData() {
        try {
            // 1. Ambil Raw Data dari Model
            $deliveryRaw = $this->repository->getDeliveryProgress();
            $locatorRaw = $this->repository->getLocatorMapping();

            // 2. Business Logic / Formatting (Jika ada manipulasi data tambahan di level PHP)
            // Contoh: Kita bisa menambahkan flag 'is_critical' di sini daripada di JS
            $locatorFormatted = array_map(function($item) {
                $item['is_critical'] = ($item['remain_del'] < 0);
                return $item;
            }, $locatorRaw);

            // 3. Return struktur data final untuk API
            return [
                'status' => 'success',
                'server_time' => date('Y-m-d H:i:s'),
                'meta' => [
                    'total_delivery_rows' => count($deliveryRaw),
                    'total_locator_rows' => count($locatorRaw)
                ],
                'data' => [
                    'delivery_progress' => $deliveryRaw,
                    'locator_mapping' => $locatorFormatted
                ]
            ];

        } catch (Exception $e) {
            return [
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }
}
?>