const REFRESH_DATA_INTERVAL = 30000
const PAGE_SWITCH_INTERVAL = 10000
const ITEMS_PER_PAGE = 10

let globalLocatorData = []
let currentPage = 0
let pageIntervalInstance

const fmtNum = new Intl.NumberFormat('en-US')

// --- Clock & Date Function ---
const updateTime = () => {
  const now = new Date()
  const clockEl = document.getElementById('clock')
  const dateEl = document.getElementById('date-display')

  if (clockEl) {
    clockEl.innerHTML = `${String(now.getHours()).padStart(
      2,
      '0'
    )}<span class="animate-pulse text-slate-500">:</span>${String(now.getMinutes()).padStart(
      2,
      '0'
    )}`
  }

  if (dateEl) {
    const options = { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' }
    dateEl.innerText = now.toLocaleDateString('en-GB', options).toUpperCase()
  }
}

// --- Data Fetching ---
async function fetchData() {
  const loading = document.getElementById('loading-indicator')
  if (loading) loading.classList.remove('hidden')

  try {
    const response = await fetch('api.php')
    const result = await response.json()
    if (result.status === 'success') {
      renderDeliveryScoreboard(result.data.delivery_progress)
      globalLocatorData = result.data.locator_mapping

      // Opsional: Jika ingin reset halaman saat data baru masuk
      // renderLocatorPage();
    }
  } catch (error) {
    console.error('Sync Error', error)
  } finally {
    if (loading) loading.classList.add('hidden')
  }
}

// --- Render Delivery Scoreboard (Left Side) ---
function renderDeliveryScoreboard(data) {
  const container = document.getElementById('delivery-container')
  if (!container) return

  container.innerHTML = ''

  let totalPlan = 0
  let totalDept = 0

  const fragment = document.createDocumentFragment()

  data.forEach((row) => {
    totalPlan += parseFloat(row.plan)
    totalDept += parseFloat(row.departure)
    const rateVal = parseFloat(row.rate)

    let bgClass = 'bg-slate-800/50 border-slate-700'
    let accentColor = '#94a3b8'

    if (row.sequence === 'AGING') {
      bgClass = 'bg-red-900/20 border-red-800'
      accentColor = '#ef4444'
    } else if (row.sequence === 'SESSION 1') {
      bgClass = 'bg-blue-900/20 border-blue-800'
      accentColor = '#3b82f6'
    }

    const div = document.createElement('div')
    div.className = `flex-1 flex items-center justify-between px-4 py-1 rounded-lg border-l-4 ${bgClass} mb-2 shadow-lg last:mb-0`
    div.innerHTML = `
            <div class="flex flex-col w-1/4">
                <span class="text-tv-xs font-mono text-slate-400 leading-tight">${
                  row.pst_display
                }</span>
                <span class="text-tv-sm font-bold tracking-wider" style="color: ${accentColor}">${
      row.sequence
    }</span>
            </div>
            <div class="flex flex-col w-1/4 items-end">
                <span class="delivery-label">PLAN</span> <!-- UPDATE: Ganti class untuk label "PLAN" --><span class="text-tv-lg font-mono font-bold text-white">${fmtNum.format(
                  row.plan
                )}</span>
            </div>
            <div class="flex flex-col w-1/4 items-end">
                <span class="delivery-label">ACTUAL</span> <!-- UPDATE: Ganti class untuk label "ACTUAL" --><span class="text-tv-lg font-mono font-bold text-info">${fmtNum.format(
                  row.departure
                )}</span>
            </div>
            <div class="flex items-center justify-end w-1/5">
                <span class="text-tv-xl font-bold ${
                  rateVal >= 100 ? 'text-success' : rateVal < 50 ? 'text-danger' : 'text-warning'
                }">${Math.round(rateVal)}%</span>
            </div>
        `
    fragment.appendChild(div)
  })
  container.appendChild(fragment)

  // Update Overall Gauge
  if (totalPlan > 0) {
    const totalRate = (totalDept / totalPlan) * 100
    const ovrRateEl = document.getElementById('overall-rate')
    const ovrBgEl = document.getElementById('overall-bar-bg')

    if (ovrRateEl) {
      ovrRateEl.innerText = totalRate.toFixed(1) + '%'
      ovrRateEl.className = `text-tv-2xl font-mono font-bold leading-none ${
        totalRate >= 98 ? 'text-success' : totalRate >= 80 ? 'text-info' : 'text-danger'
      }`
    }

    if (ovrBgEl) {
      ovrBgEl.className = `h-full w-full opacity-30 absolute bottom-0 transition-all duration-1000 ${
        totalRate >= 98 ? 'bg-success' : totalRate >= 80 ? 'bg-info' : 'bg-danger'
      }`
      ovrBgEl.style.height = Math.min(totalRate, 100) + '%'
    }
  }
}

// --- Render Locator Table (Right Side - Pagination Logic) ---
function renderLocatorPage() {
  const tbody = document.getElementById('locator-table-body')
  if (!tbody) return

  if (!globalLocatorData || globalLocatorData.length === 0) {
    tbody.innerHTML = ''
    for (let i = 0; i < ITEMS_PER_PAGE; i++) {
      const content =
        i === Math.floor(ITEMS_PER_PAGE / 2)
          ? '<span class="text-slate-500">NO DATA AVAILABLE</span>'
          : '&nbsp;'
      const tr = `<tr class="tv-table-row bg-[#1e293b]"><td colspan="6" class="text-center tv-cell">${content}</td></tr>`
      tbody.innerHTML += tr
    }
    return
  }

  const totalPages = Math.ceil(globalLocatorData.length / ITEMS_PER_PAGE)
  if (currentPage >= totalPages) currentPage = 0

  const pageIndicator = document.getElementById('page-indicator')
  if (pageIndicator) pageIndicator.innerText = `${currentPage + 1}/${totalPages}`

  const start = currentPage * ITEMS_PER_PAGE
  const end = start + ITEMS_PER_PAGE
  const pageData = globalLocatorData.slice(start, end)
  const emptyRowsNeeded = ITEMS_PER_PAGE - pageData.length

  tbody.innerHTML = ''

  // 1. Render Data Asli
  pageData.forEach((row, index) => {
    const remain = parseFloat(row.remain_del)
    const isCritical = row.is_critical || remain < 0

    let rowClass = index % 2 === 0 ? 'bg-[#1e293b]' : 'bg-[#161f32]'
    let locColor = 'text-info'

    if (isCritical) {
      rowClass = 'bg-red-900/30 blink-critical border-l-4 border-danger'
      locColor = 'text-white'
    }

    const tr = `
            <tr class="tv-table-row ${rowClass}">
                <td class="tv-cell pl-4 font-bold ${locColor} text-tv-lg">${row.locator}</td>
                <td class="tv-cell text-slate-400 text-tv-sm">${row.pst}</td>
                <td class="tv-cell">
                    <div class="text-slate-200 text-tv-base leading-none truncate max-w-[300px]">${
                      row.model
                    }</div>
                    <div class="pn-text">${
                      row.pn
                    }</div> <!-- UPDATE: Ganti class untuk "pn" --></td>
                <td class="tv-cell text-tv-sm text-slate-300">${row.lot}</td>
                <td class="tv-cell text-right font-bold text-tv-lg">${fmtNum.format(row.qty)}</td>
                <td class="tv-cell text-right font-bold text-tv-lg ${
                  isCritical ? 'text-red-400' : 'text-emerald-400'
                }">
                    ${fmtNum.format(remain)}
                </td>
            </tr>
        `
    tbody.innerHTML += tr
  })

  // 2. Render Baris Kosong (Padding) agar tinggi tabel tetap stabil
  for (let i = 0; i < emptyRowsNeeded; i++) {
    const globalIndex = pageData.length + i
    const rowClass = globalIndex % 2 === 0 ? 'bg-[#1e293b]' : 'bg-[#161f32]'

    const emptyTr = `
            <tr class="tv-table-row ${rowClass}">
                <td class="tv-cell pl-4">&nbsp;</td>
                <td class="tv-cell">&nbsp;</td>
                <td class="tv-cell">&nbsp;</td>
                <td class="tv-cell">&nbsp;</td>
                <td class="tv-cell">&nbsp;</td>
                <td class="tv-cell">&nbsp;</td>
            </tr>
        `
    tbody.innerHTML += emptyTr
  }

  currentPage++
}

// --- Initialization ---
document.addEventListener('DOMContentLoaded', () => {
  setInterval(updateTime, 1000)
  updateTime()

  fetchData()
  setInterval(fetchData, REFRESH_DATA_INTERVAL)

  setTimeout(renderLocatorPage, 500)

  if (pageIntervalInstance) clearInterval(pageIntervalInstance)
  pageIntervalInstance = setInterval(renderLocatorPage, PAGE_SWITCH_INTERVAL)
})
